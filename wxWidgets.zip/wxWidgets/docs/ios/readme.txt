   Welcome to wxWidgets for iOS
   ----------------------------

wxiOS is far from a full supported port, but can be used
as base for simple applications and future improvements.

Please send problems concerning installation, feature requests,
bug reports or comments to the wxWidgets users list. These can
be found at https://www.wxwidgets.org/support/mailing-lists/

wxWidgets doesn't come with any guarantee whatsoever. It
might crash your harddisk or destroy your monitor. It doesn't
claim to be suitable for any special or general purpose.

  Regards,

    The wxWidgets Team
