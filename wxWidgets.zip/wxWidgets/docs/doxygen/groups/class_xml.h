/////////////////////////////////////////////////////////////////////////////
// Name:        class_xml.h
// Purpose:     XML classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_xml XML
@ingroup group_class

Group of classes loading and saving XML documents (http://www.w3.org/XML/).

*/

